# MEME HUB

A responsive black-and-white social meme platform prototype recreated from the supplied Figma Make screenshots.

## Pages included

- Landing / feature hub
- Home Feed
- Explore
- Create Meme
- Messages
- Dashboard
- Sticker Shop
- Delivery Tracking
- Trending Challenge
- Marketplace
- Notifications
- Monetization / Profile demo

## Tech

- HTML5
- CSS3
- Vanilla JavaScript
- No build step
- Works on GitHub Pages

## Run locally

Open `index.html` in a browser.

For a local server:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000`.

## GitHub Pages

1. Upload the contents of this `meme-hub` folder to your repository.
2. Go to **Settings → Pages**.
3. Select **Deploy from a branch**.
4. Choose `main` and `/ (root)` if `meme-hub` is the repository root, or configure the project folder as needed.
5. Save and wait for GitHub Pages to publish.

## Notes

The included image assets are crops from the screenshots supplied for this project. Replace them with your original meme/avatar assets if you have the source files.
