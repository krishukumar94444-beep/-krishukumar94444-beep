const app = document.getElementById("app");
const toast = document.getElementById("toast");

const icons = {home:"⌂", explore:"◉", create:"+", messages:"◌", dashboard:"▦", shop:"▢", truck:"▱", trend:"↗", bell:"♧", user:"♙", trophy:"♜", money:"$", box:"◇", settings:"⚙"};

const memes = [
  {user:"memequeen", avatar:"assets/profile.png", img:"assets/meme1.png", likes:1240, comments:84},
  {user:"viralking", avatar:"assets/alex.png", img:"assets/meme2.png", likes:982, comments:51},
  {user:"college_memer", avatar:"assets/james.png", img:"assets/meme3.png", likes:761, comments:39}
];

const messages = [
  {name:"Alex Kumar", avatar:"assets/alex.png", preview:"Check out this template!", time:"16 minutes ago", unread:true},
  {name:"Emma Wilson", avatar:"assets/emma.png", preview:"You: Sure! What do you have in mind?", time:"about 2 hours ago"},
  {name:"James Park", avatar:"assets/james.png", preview:"You: No problem! Your content is amazing", time:"about 3 hours ago"},
  {name:"Priya Sharma", avatar:"assets/priya.png", preview:"You: Just keep posting consistently and engage with your audience!", time:"about 5 hours ago"}
];

function route(){ return location.hash.replace("#/","") || "landing"; }
function go(r){ location.hash = "#/" + r; }
function showToast(msg){ toast.textContent=msg; toast.classList.add("show"); setTimeout(()=>toast.classList.remove("show"),1800); }

function topbar(){
  return `<header class="topbar">
    <a class="brand" href="#/home">
      <div class="brand-mark">ϟ</div>
      <div><div class="brand-name">MEME HUB</div><div class="brand-sub">Your daily dose of laughter</div></div>
    </a>
    <div class="top-actions"><button class="btn" onclick="go('delivery')">▱ &nbsp; Track Order</button><button class="icon-btn" onclick="go('messages')">♧</button></div>
  </header>`;
}
function bottomNav(active){
  const items=[["home","⌂","Home"],["explore","◉","Explore"],["create","+","Create"],["messages","◌","Messages"],["dashboard","▦","Dashboard"]];
  return `<nav class="bottom-nav">${items.map(([r,i,l])=>`<button class="nav-item ${active===r?"active":""}" onclick="go('${r}')"><span>${i}</span><span>${l}</span></button>`).join("")}</nav>`;
}
function shell(content,active="home"){ app.innerHTML=`<div class="app-shell">${topbar()}<main class="page">${content}</main>${bottomNav(active)}</div>`; }

function landing(){
  const cards=[
    ["home","⌂","Home Feed","Browse trending memes and content"],
    ["messages","▢","Messages","Chat with other creators in real-time"],
    ["shop","▣","Sticker Shop","Order physical stickers of your memes"],
    ["delivery","▱","Delivery Tracking","Track all your orders and deliveries"],
    ["dashboard","↗","Dashboard","View your analytics and stats"],
    ["explore","◉","Explore","Discover new content and creators"],
    ["create","+","Create Meme","Design your own memes with tools"],
    ["marketplace","▤","Marketplace","Buy premium templates and assets"],
    ["notifications","♧","Notifications","Stay updated with latest activity"],
    ["challenges","♜","Challenges","Participate in meme challenges"],
    ["monetization","$","Monetization","Earn money from your content"],
    ["profile","♙","Profile","Manage your account and settings"],
    ["delivery","◇","Sample Order","View a sample order tracking"]
  ];
  app.innerHTML=`<div class="app-shell">
    <section class="hero"><h1>MEME HUB</h1><p>Professional Black &amp; White Social Meme Platform</p><small>Select a feature below to explore the fully functional app</small></section>
    <section class="feature-grid">${cards.map(c=>`<button class="feature-card" style="text-align:left" onclick="go('${c[0]}')"><div class="feature-icon">${c[1]}</div><h3>${c[2]}</h3><p>${c[3]}</p></button>`).join("")}</section>
  </div>`;
}

function home(){
  shell(`<div class="promo-row">
    <button class="promo" onclick="go('shop')" style="border:0;text-align:left"><div class="promo-icon">▣</div><div><h3>Sticker Shop</h3><p>Order premium physical stickers 🎨</p></div></button>
    <button class="promo" onclick="go('challenges')" style="border:0;text-align:left"><div class="promo-icon">↗</div><div><h3>Trending Challenge</h3><p>Join "Relatable College Memes" 🔥</p></div></button>
  </div>
  <div class="section-head"><div><h2>Trending Memes</h2><p>Fresh content from the community</p></div><button class="btn dark" onclick="go('create')">＋ Create</button></div>
  <div class="meme-grid">${memes.map((m,i)=>memeCard(m,i)).join("")}</div>`,"home");
}
function memeCard(m,i){return `<article class="meme-card">
  <div class="user-row"><img class="avatar" src="${m.avatar}"><span class="username">${m.user}</span></div>
  <img class="meme-image" src="${m.img}" alt="Meme">
  <div class="meme-actions"><div class="action-row"><button class="action" onclick="like(this,${m.likes})">♡ <span>${m.likes}</span></button><button class="action" onclick="showToast('Comment panel opened')">◌ ${m.comments}</button></div><button class="action" onclick="showToast('Meme shared!')">↗</button></div>
</article>`}

function explore(){
  shell(`<h1 class="page-title">Explore</h1>
  <input id="exploreSearch" class="search" placeholder="⌕  Search memes, creators, hashtags..." oninput="filterExplore(this.value)">
  <div class="tabs"><button class="tab active">↗ &nbsp; Trending</button><button class="tab" onclick="showToast('Creators tab selected')">♙ &nbsp; Creators</button><button class="tab" onclick="showToast('Hashtags tab selected')"># &nbsp; Hashtags</button></div>
  <div id="exploreGrid" class="explore-grid">${memes.map(m=>`<article class="explore-card" data-search="${m.user.toLowerCase()}"><img src="${m.img}" alt=""><div class="user-row"><img class="avatar" src="${m.avatar}"><span class="username">${m.user}</span></div></article>`).join("")}</div>`,"explore");
}
function filterExplore(q){document.querySelectorAll(".explore-card").forEach(x=>x.style.display=x.dataset.search.includes(q.toLowerCase())?"block":"none")}

function create(){
  shell(`<h1 class="page-title">Create Meme</h1>
  <div class="create-box"><div class="create-preview"><div class="meme-canvas" id="canvas"><img src="assets/meme1.png"><div class="canvas-text" id="canvasText">Your meme caption goes here</div></div></div></div>
  <div class="ai-box"><h2>✣ AI Caption Suggestions</h2><div class="chips">${["When Monday hits different 😭","Me pretending to work:","Nobody: ... Me:","POV: You forgot it was due today","This could be us but you playin'","It really do be like that"].map(t=>`<button class="chip" onclick="useCaption('${t.replace(/'/g,"\\'")}')">${t}</button>`).join("")}</div></div>
  <div class="tool-tabs"><button class="tool-tab active">T &nbsp; Text</button><button class="tool-tab" onclick="showToast('Filters selected')">⚙ &nbsp; Filters</button><button class="tool-tab" onclick="showToast('Sticker picker opened')">▧ &nbsp; Stickers</button><button class="tool-tab" onclick="showToast('Template gallery opened')">✣ &nbsp; Templates</button></div>
  <div class="field"><label>Add Text</label><div style="display:flex;gap:10px"><input id="captionInput" placeholder="Enter text..." oninput="updateCaption(this.value)"><button class="btn dark" onclick="updateCaption(document.getElementById('captionInput').value)">Add</button></div></div>
  <div class="field"><label>Font Size: <span id="fontValue">32</span>px</label><input class="range" type="range" min="18" max="64" value="32" oninput="setFont(this.value)"></div>
  <div class="field"><label>Font Family</label><div class="chips"><button class="chip" onclick="setFontFamily('Impact')">Impact</button><button class="chip" onclick="setFontFamily('Arial')">Arial</button></div></div>
  <button class="btn dark" onclick="showToast('Meme saved to your gallery!')">Save Meme</button>`,"create");
}
function updateCaption(v){document.getElementById("canvasText").textContent=v||"Your meme caption goes here"}
function useCaption(v){document.getElementById("captionInput").value=v;updateCaption(v)}
function setFont(v){document.getElementById("fontValue").textContent=v;document.getElementById("canvasText").style.fontSize=v+"px"}
function setFontFamily(v){document.getElementById("canvasText").style.fontFamily=v}

function messagesPage(){
  shell(`<div style="display:flex;justify-content:space-between;align-items:center"><h1 class="page-title">Messages</h1><div>▧ &nbsp; ⋮</div></div>
  <input class="search" placeholder="⌕  Search conversations..." oninput="filterMessages(this.value)">
  <div id="messageList" class="message-list">${messages.map(m=>`<button class="message-item" data-name="${m.name.toLowerCase()}" onclick="openChat('${m.name}')"><img class="avatar" src="${m.avatar}"><div class="message-main"><div class="message-name">${m.name} ${m.unread?'<sup style="background:#000;color:#fff;border-radius:50%;padding:4px 7px">1</sup>':''}</div><div class="message-preview">${m.preview}</div></div><div class="message-time">${m.time}</div></button>`).join("")}</div>`,"messages");
}
function filterMessages(q){document.querySelectorAll(".message-item").forEach(x=>x.style.display=x.dataset.name.includes(q.toLowerCase())?"flex":"none")}
function openChat(name){showToast("Opening chat with "+name)}

function dashboard(){
  shell(`<div style="display:flex;justify-content:space-between;align-items:center"><h1 class="page-title">Dashboard</h1><button class="icon-btn" onclick="showToast('Settings opened')">⚙</button></div>
  <section class="dashboard-profile"><img class="profile-big" src="assets/profile.png"><div class="profile-info"><h2>memequeen</h2><p>Creating viral memes since 2024 🔥 • Level 42 • Meme Score: 892K</p><div class="profile-actions"><button class="btn dark" onclick="showToast('Edit profile opened')">Edit Profile</button><button class="btn" onclick="showToast('Profile link copied')">Share Profile</button><button class="btn" onclick="go('delivery')">◇ My Orders</button></div><div style="display:flex;gap:65px;margin-top:25px"><div><strong>234</strong><div class="page-sub">Posts</div></div><div><strong>45.2K</strong><div class="page-sub">Followers</div></div><div><strong>892</strong><div class="page-sub">Following</div></div></div></div></section>
  <section class="stats">
    ${[["♡","892K","Total Likes"],["◉","2.4M","Total Views"],["↗","94.2%","Engagement Rate"],["$","₹12.5K","Earnings"]].map(s=>`<div class="stat"><div class="stat-icon">${s[0]}</div><strong>${s[1]}</strong><span>${s[2]}</span></div>`).join("")}
  </section>
  <section class="orders"><div class="orders-head"><h2>▱ Recent Orders</h2><button class="btn" onclick="go('delivery')">View All</button></div><div class="order"><div><strong>MEME-STK-2048</strong><div class="page-sub">12 premium stickers</div></div><strong>Delivered</strong></div><div class="order"><div><strong>MEME-STK-2031</strong><div class="page-sub">Custom meme sticker pack</div></div><strong>In transit</strong></div></section>`,"dashboard");
}

function shop(){
  shell(`<h1 class="page-title">Sticker Shop</h1><p class="page-sub">Turn your favorite memes into premium physical stickers.</p>
  <div class="shop-grid">${[
    ["Classic Meme Pack","₹299","😂"],["Custom Die-Cut Sticker","₹149","🔥"],["Creator Bundle","₹599","⚡"],["Laptop Sticker Set","₹349","😎"],["Holographic Pack","₹449","✨"],["Mega Meme Box","₹799","📦"]
  ].map(p=>`<article class="product"><div class="product-art">${p[2]}</div><h3>${p[0]}</h3><div class="price">${p[1]}</div><button class="btn dark" onclick="showToast('${p[0]} added to cart')">Add to Cart</button></article>`).join("")}</div>`,"home");
}

function delivery(){
  shell(`<h1 class="page-title">Delivery Tracking</h1><p class="page-sub">Track your meme merchandise orders.</p>
  <div class="orders"><div class="order" style="border-top:0;margin-top:0"><div><strong>Order #MEME-2048</strong><div class="page-sub">Premium Meme Sticker Pack • 12 items</div></div><strong>Delivered</strong></div><div class="order"><div><strong>Order #MEME-2031</strong><div class="page-sub">Custom Creator Bundle</div></div><strong>Out for delivery</strong></div><div class="order"><div><strong>Order #MEME-1992</strong><div class="page-sub">Holographic Sticker Set</div></div><strong>Processing</strong></div></div>
  <div class="ai-box" style="margin-top:25px"><h2>Live tracking</h2><p class="page-sub">Your current package is on the way. Estimated delivery: tomorrow.</p><button class="btn dark" onclick="showToast('Tracking details refreshed')">Refresh Tracking</button></div>`,"dashboard");
}

function challenges(){
  shell(`<h1 class="page-title">Trending Challenge</h1><p class="page-sub">Join the "Relatable College Memes" challenge 🔥</p>
  <div class="promo"><div class="promo-icon">↗</div><div><h3>Relatable College Memes</h3><p>Post your funniest campus moment and climb the leaderboard.</p></div></div>
  <div class="stats" style="margin-top:22px"><div class="stat"><strong>18.4K</strong><span>Participants</span></div><div class="stat"><strong>2.7M</strong><span>Views</span></div><div class="stat"><strong>₹10K</strong><span>Prize Pool</span></div><div class="stat"><strong>3 days</strong><span>Remaining</span></div></div>
  <button class="btn dark" onclick="go('create')">Create Challenge Meme</button>`,"explore");
}

function marketplace(){ shop(); }
function notifications(){ shell(`<h1 class="page-title">Notifications</h1><div class="empty">You're all caught up 🎉</div>`,"home"); }
function monetization(){ shell(`<h1 class="page-title">Monetization</h1><p class="page-sub">Turn your meme audience into creator income.</p><div class="stats"><div class="stat"><strong>₹12.5K</strong><span>This month</span></div><div class="stat"><strong>94.2%</strong><span>Engagement</span></div><div class="stat"><strong>18</strong><span>Brand offers</span></div><div class="stat"><strong>892K</strong><span>Meme score</span></div></div><button class="btn dark" onclick="showToast('Creator payout setup opened')">Set Up Payouts</button>`,"dashboard");}
function profile(){ dashboard(); }

function like(btn,n){const s=btn.querySelector("span");let v=parseInt(s.textContent)+1;s.textContent=v;btn.classList.add("liked");btn.firstChild.textContent="♥ "}

function render(){
  const r=route();
  const map={landing,home,explore,create,messages:messagesPage,dashboard,shop,delivery,challenges,marketplace,notifications,monetization,profile};
  (map[r]||landing)();
}
window.addEventListener("hashchange",render);
window.addEventListener("load",render);
